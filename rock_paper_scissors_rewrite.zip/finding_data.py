person = input("What's your name?: ")
options = ["Collins", "Mark", "Peter", "Janet"]

if person in options:
    print("Found!")
else:
    print("Not found!")    
